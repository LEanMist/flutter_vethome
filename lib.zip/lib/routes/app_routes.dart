import 'dart:async';

import 'package:flutter/material.dart';

import '../data/vet_repository.dart';
import '../pages/cliente/endereco/addresses_page.dart';
import '../pages/cliente/consulta/agenda_page.dart';
import '../pages/chat_page.dart';
import '../pages/config_page.dart';
import '../pages/veterinario/gabriela_area_page.dart';
import '../pages/veterinario/gabriela_splash_screen.dart';
import '../models/saved_address.dart';
import '../models/pet_model.dart';
import '../pages/cliente/consulta/agendamentos_page.dart';
import '../pages/cliente/pet/detalhes_pet_page.dart';
import '../pages/cliente/pet/editar_pet_page.dart';
import '../pages/cliente/login_page.dart';
import '../pages/cliente/perfil_page.dart';
import '../pages/cliente/pet/pets_page.dart';
import '../pages/cliente/pet/saude_page.dart';
import '../pages/veterinario/sobre_page.dart';
import '../pages/splash/splashScreen.dart';
import '../pages/splash/sucessoScreen.dart';
import '../pages/cliente/consulta/vacinacao_page.dart';
import '../pages/cliente/consulta/nova_consulta_page.dart';
import '../pages/cliente/cadastro_page.dart';
import '../pages/cliente/endereco/endereco_page.dart';
import '../pages/cliente/pet/cadastroPet_page.dart';
import '../screens/pets.dart'
    show ConvenioScreen, EscolhaPetScreen, ServicosScreen, openPetChoiceDialog;

Map<String, String> _formDataFromRoute(BuildContext context) {
  final arguments = ModalRoute.of(context)?.settings.arguments;
  if (arguments is! Map) return const {};
  return arguments.map<String, String>(
    (key, value) => MapEntry(key.toString(), value.toString()),
  );
}

PetModel? _petFromRoute(BuildContext context) {
  final arguments = ModalRoute.of(context)?.settings.arguments;
  if (arguments is PetModel) return VetRepository.petById(arguments.id);

  final args = arguments is Map ? arguments : const <String, dynamic>{};
  final name = args['petName'];
  final id = args['petId'];
  if (id is String) return VetRepository.petById(id);
  // Compatibilidade de entrada com argumentos antigos, sem criar outro pet.
  if (name is String) {
    return VetRepository.pets.where((pet) => pet.name == name).firstOrNull;
  }
  return VetRepository.selectedPet;
}

Widget _petPage(BuildContext context, Widget Function(PetModel) builder) {
  final pet = _petFromRoute(context);
  return pet == null ? const PetsPage() : builder(pet);
}

class AppRoutes {
  AppRoutes._();

  static Map<String, WidgetBuilder> get routes => {
    '/': (_) => const SplashScreen(),
    // Mantém links antigos apontando para a primeira aba do Cliente.
    '/home': (_) => const PetsPage(),
    '/login': (_) => const LoginPage(),
    '/gabriela/splash': (_) => const GabrielaSplashScreen(),
    '/gabriela/login': (_) => const LoginPage.veterinarianDemo(),
    '/gabriela': (_) => const GabrielaAreaPage(),
    '/gabriela/perfil': (_) => const GabrielaAreaPage(initialIndex: 0),
    '/gabriela/mensagens': (_) => const GabrielaAreaPage(initialIndex: 1),
    '/gabriela/agenda': (_) => const GabrielaAreaPage(initialIndex: 2),
    '/gabriela/configuracoes': (_) => const GabrielaAreaPage(initialIndex: 3),
    '/cadastro': (context) => CadastroScreen(
      entry: switch (ModalRoute.of(context)?.settings.arguments) {
        final CadastroEntry entry => entry,
        _ => null,
      },
    ),
    '/endereco': (context) =>
        EnderecoScreen(initialData: _formDataFromRoute(context)),
    '/cadastroPet': (context) =>
        CadastroPetScreen(initialData: _formDataFromRoute(context)),
    '/sucesso': (context) => SucessoScreen(
      saved: ModalRoute.of(context)?.settings.arguments == true,
    ),
    '/pets': (_) => const PetsPage(),
    '/pet': (context) => _petPage(context, (pet) => DetalhesPetPage(pet: pet)),
    '/editPet': (context) =>
        _petPage(context, (pet) => EditarPetPage(pet: pet)),
    '/escolhaPet': (_) => const _PetChoiceFlowRoute(),
    '/servicos': (_) => const ServicosScreen(),
    '/convenio': (_) => const ConvenioScreen(),
    '/perfil': (_) => const PerfilPage(),
    '/chat': (_) => const ChatScreen(),
    '/sobre': (_) => const SobreScreen(),
    '/agenda': (context) => AgendaScreen(
      initialDate: ModalRoute.of(context)?.settings.arguments is DateTime
          ? ModalRoute.of(context)!.settings.arguments as DateTime
          : null,
    ),
    '/saude': (context) => _petPage(context, (pet) => SaudePage(pet: pet)),
    '/vacinacao': (context) =>
        _petPage(context, (pet) => VacinacaoPage(pet: pet)),
    '/agendamentos': (context) =>
        _petPage(context, (pet) => AgendamentosPage(pet: pet)),
    '/nova-consulta': (context) {
      final args = ModalRoute.of(context)?.settings.arguments;
      final values = args is Map ? args : const <String, dynamic>{};
      final pet = values['petId'] is String
          ? VetRepository.petById(values['petId'] as String)
          : values['pet'] is PetModel
          ? VetRepository.petById((values['pet'] as PetModel).id)
          : VetRepository.selectedPet;
      if (pet == null) return const PetsPage();
      final service = values['service'];
      final plan = values['plan'];
      return NovaConsultaPage(
        pet: pet,
        service: service is String ? service : 'Consulta Geral',
        plan: plan is String ? plan : 'Particular',
      );
    },
    '/config': (_) => const ConfigScreen(),
    '/enderecos': (_) => const AddressesPage(),
    '/editar-endereco': (context) => AddressEditorPage(
      address: ModalRoute.of(context)?.settings.arguments as SavedAddress?,
    ),
  };
}

/// A rota móvel mantém a Agenda ao fundo e abre o painel CHOICE_PET_WIDGET.
/// Em telas largas, a página original de seleção continua disponível.
class _PetChoiceFlowRoute extends StatefulWidget {
  const _PetChoiceFlowRoute();

  @override
  State<_PetChoiceFlowRoute> createState() => _PetChoiceFlowRouteState();
}

class _PetChoiceFlowRouteState extends State<_PetChoiceFlowRoute> {
  bool _dialogScheduled = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.sizeOf(context).width >= 900 || _dialogScheduled) return;

    _dialogScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(openPetChoiceDialog(context));
    });
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.sizeOf(context).width >= 900) {
      return const EscolhaPetScreen();
    }
    return AgendaScreen();
  }
}
