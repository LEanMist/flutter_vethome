import 'package:flutter/services.dart';

Map<String, String> withoutRegistrationPasswords(Map<String, String> values) =>
    <String, String>{
      for (final entry in values.entries)
        if (!_isRegistrationPasswordKey(entry.key)) entry.key: entry.value,
    };

bool _isRegistrationPasswordKey(String key) {
  final label = key.split('.').last.trim().toLowerCase();
  return label == 'senha' || label == 'confirmar senha';
}

bool isValidCpf(String value) {
  final input = value.trim();
  if (!RegExp(r'^(?:\d{11}|\d{3}\.\d{3}\.\d{3}-\d{2})$').hasMatch(input)) {
    return false;
  }

  final digits = input
      .replaceAll(RegExp(r'\D'), '')
      .codeUnits
      .map((code) => code - 48)
      .toList(growable: false);
  if (digits.toSet().length == 1) return false;

  int checkDigit(int length) {
    var sum = 0;
    for (var i = 0; i < length; i++) {
      sum += digits[i] * (length + 1 - i);
    }
    final remainder = sum % 11;
    return remainder < 2 ? 0 : 11 - remainder;
  }

  return checkDigit(9) == digits[9] && checkDigit(10) == digits[10];
}

bool hasCompleteTutorRegistrationData(Map<String, String> values) {
  final name = values['client.Nome Completo']?.trim() ?? '';
  final birthDate = values['client.Data de Nascimento'] ?? '';
  final cpf = values['client.CPF'] ?? '';
  final phone = values['client.Telefone/Celular'] ?? '';
  final email = values['client.E-mail']?.trim() ?? '';
  final phoneDigits = phone.replaceAll(RegExp(r'\D'), '');

  return name.isNotEmpty &&
      parseBirthDate(birthDate) != null &&
      isValidCpf(cpf) &&
      (phoneDigits.length == 10 || phoneDigits.length == 11) &&
      isValidTutorEmail(email);
}

bool isValidTutorEmail(String text) {
  final parts = text.trim().split('@');
  if (parts.length != 2) return false;
  final local = parts.first;
  return RegExp(r'^[^\s.@]+(?:\.[^\s.@]+)*$').hasMatch(local) &&
      RegExp(
        r'^(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?$',
        unicode: true,
      ).hasMatch(parts.last);
}

class DigitsMask extends TextInputFormatter {
  const DigitsMask(this.pattern);
  final String pattern;

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final digits = newValue.text.replaceAll(RegExp(r'\D'), '');
    final count = pattern.split('').where((c) => c == '#').length;
    final value = digits.substring(0, digits.length.clamp(0, count));
    final out = StringBuffer();
    var index = 0;
    for (final char in pattern.split('')) {
      if (index >= value.length) break;
      if (char == '#') {
        out.write(value[index++]);
      } else {
        out.write(char);
      }
    }
    final text = out.toString();
    final digitsBefore = newValue.text
        .substring(
          0,
          newValue.selection.extentOffset.clamp(0, newValue.text.length),
        )
        .replaceAll(RegExp(r'\D'), '')
        .length;
    var cursor = 0, seen = 0;
    while (cursor < text.length && seen < digitsBefore) {
      if (RegExp(r'\d').hasMatch(text[cursor])) seen++;
      cursor++;
    }
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: cursor),
    );
  }
}

class PhoneMask extends TextInputFormatter {
  const PhoneMask({this.acceptBrazilCountryCode = false});
  final bool acceptBrazilCountryCode;
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var input = newValue;
    var length = input.text.replaceAll(RegExp(r'\D'), '').length;
    if (acceptBrazilCountryCode) {
      final text = input.text.trimLeft();
      if (text.startsWith('+')) {
        if (!text.startsWith('+55') || length <= 2 || length > 13) {
          return oldValue;
        }
        final local = text.substring(3);
        input = TextEditingValue(
          text: local,
          selection: TextSelection.collapsed(offset: local.length),
        );
        length -= 2;
      } else if (length > 11) {
        return oldValue;
      }
    }
    return DigitsMask(
      length <= 10 ? '(##) ####-####' : '(##) #####-####',
    ).formatEditUpdate(oldValue, input);
  }
}

DateTime? parseBirthDate(String text) {
  final date = parseCalendarDate(text);
  return date == null || date.isAfter(DateTime.now()) ? null : date;
}

DateTime? parseCalendarDate(String text) {
  final match = RegExp(r'^(\d{2})/(\d{2})/(\d{4})$').firstMatch(text);
  if (match == null) return null;
  final day = int.parse(match[1]!),
      month = int.parse(match[2]!),
      year = int.parse(match[3]!);
  final date = DateTime(year, month, day);
  return year >= 1900 && date.day == day && date.month == month ? date : null;
}

String normalizedText(String text) {
  const accents = 'áàâãäéèêëíìîïóòôõöúùûüç';
  const plain = 'aaaaaeeeeiiiiooooouuuuc';
  var result = text.toLowerCase().trim();
  for (var i = 0; i < accents.length; i++) {
    result = result.replaceAll(accents[i], plain[i]);
  }
  return result;
}

List<String> breedsFor(String species) => species.toLowerCase().contains('gato')
    ? const [
        'SRD / Sem raça definida',
        'Siamês',
        'Persa',
        'Maine Coon',
        'Ragdoll',
        'Bengal',
        'Sphynx',
        'British Shorthair',
      ]
    : const [
        'SRD / Sem raça definida',
        'Golden Retriever',
        'Labrador Retriever',
        'Lulu da Pomerânia',
        'Poodle',
        'Shih Tzu',
        'Yorkshire Terrier',
        'Bulldog',
        'Beagle',
        'Pastor Alemão',
        'Dachshund',
        'Rottweiler',
        'Border Collie',
      ];

/// Input in kilograms: one decimal separator, never thousands/grouping.
double? parsePetWeight(String text) {
  final value = text.trim();
  if (!RegExp(r'^\d+(?:[,.]\d{1,3})?$').hasMatch(value)) return null;
  final kg = double.tryParse(value.replaceAll(',', '.'));
  return isValidPetWeight(kg) ? kg : null;
}

// Entry validation for the supported dog/cat form; no display clamping.
bool isValidPetWeight(double? kg) =>
    kg != null && kg.isFinite && kg > 0 && kg <= 250;
