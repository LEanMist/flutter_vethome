import 'package:flutter/material.dart';

import '../data/vet_repository.dart';
import '../models/pet_model.dart';
import 'cliente/endereco/addresses_page.dart';
import 'cliente/consulta/agendamentos_page.dart';
import 'cliente/consulta/agenda_page.dart';
import '../pages/chat_page.dart';
import '../pages/config_page.dart';
import 'cliente/pet/detalhes_pet_page.dart';
import 'cliente/pet/editar_pet_page.dart';
import 'cliente/login_page.dart';
import 'cliente/consulta/nova_consulta_page.dart';
import 'cliente/perfil_page.dart';
import 'veterinario/gabriela_area_page.dart';
import 'veterinario/gabriela_splash_screen.dart';
import 'cliente/pet/pets_page.dart';
import 'cliente/pet/saude_page.dart';
import 'veterinario/sobre_page.dart';
import 'splash/splashScreen.dart';
import 'splash/sucessoScreen.dart';
import 'cliente/consulta/vacinacao_page.dart';
import 'cliente/cadastro_page.dart';
import 'cliente/endereco/endereco_page.dart';
import 'cliente/pet/cadastroPet_page.dart';
import '../screens/pets.dart'
    show ConvenioScreen, EscolhaPetScreen, ServicosScreen;

class TestePage extends StatelessWidget {
  const TestePage({super.key, this.selectionMode = false});

  final bool selectionMode;

  Widget _withSelectedPet(Widget Function(PetModel) builder) {
    final pet = VetRepository.selectedPet;
    return pet == null ? const PetsPage() : builder(pet);
  }

  @override
  Widget build(BuildContext context) {
    final telas = <({String titulo, IconData icone, WidgetBuilder pagina})>[
      (
        titulo: 'Splash',
        icone: Icons.play_arrow_outlined,
        pagina: (_) => const SplashScreen(),
      ),
      (titulo: 'Login', icone: Icons.login, pagina: (_) => const LoginPage()),
      (
        titulo: 'Cadastro',
        icone: Icons.person_add_alt_1,
        pagina: (_) => const CadastroScreen(),
      ),
      (
        titulo: 'Endereço',
        icone: Icons.location_on_outlined,
        pagina: (_) => const EnderecoScreen(),
      ),
      (
        titulo: 'Cadastro de pet',
        icone: Icons.add_circle_outline,
        pagina: (_) => const CadastroPetScreen(),
      ),
      (
        titulo: 'Sucesso no cadastro',
        icone: Icons.check_circle_outline,
        pagina: (_) => const SucessoScreen(saved: true),
      ),
      (
        titulo: 'Endereços',
        icone: Icons.location_city_outlined,
        pagina: (_) => const AddressesPage(),
      ),
      (
        titulo: 'Editar endereço',
        icone: Icons.edit_location_alt_outlined,
        pagina: (_) => const AddressEditorPage(),
      ),
      (titulo: 'Pets', icone: Icons.pets, pagina: (_) => const PetsPage()),
      (
        titulo: 'Detalhes do pet',
        icone: Icons.info_outline,
        pagina: (_) => _withSelectedPet((pet) => DetalhesPetPage(pet: pet)),
      ),
      (
        titulo: 'Editar pet',
        icone: Icons.edit_outlined,
        pagina: (_) => _withSelectedPet((pet) => EditarPetPage(pet: pet)),
      ),
      (
        titulo: 'Escolha de pet',
        icone: Icons.pets_outlined,
        pagina: (_) => const EscolhaPetScreen(),
      ),
      (
        titulo: 'Serviços',
        icone: Icons.medical_services_outlined,
        pagina: (_) => const ServicosScreen(),
      ),
      (
        titulo: 'Convênio',
        icone: Icons.health_and_safety_outlined,
        pagina: (_) => const ConvenioScreen(),
      ),
      (
        titulo: 'Perfil',
        icone: Icons.person_outline,
        pagina: (_) => const PerfilPage(),
      ),
      (
        titulo: 'Conversa',
        icone: Icons.chat_bubble_outline,
        pagina: (_) => const ChatScreen(),
      ),
      (
        titulo: 'Sobre',
        icone: Icons.info_outline,
        pagina: (_) => const SobreScreen(),
      ),
      (
        titulo: 'Agenda',
        icone: Icons.calendar_month_outlined,
        pagina: (_) => const AgendaScreen(),
      ),
      (
        titulo: 'Saúde do pet',
        icone: Icons.favorite_border,
        pagina: (_) => _withSelectedPet((pet) => SaudePage(pet: pet)),
      ),
      (
        titulo: 'Vacinação',
        icone: Icons.vaccines_outlined,
        pagina: (_) => _withSelectedPet((pet) => VacinacaoPage(pet: pet)),
      ),
      (
        titulo: 'Agendamentos',
        icone: Icons.event_note_outlined,
        pagina: (_) => _withSelectedPet((pet) => AgendamentosPage(pet: pet)),
      ),
      (
        titulo: 'Nova consulta',
        icone: Icons.add_task,
        pagina: (_) => _withSelectedPet(
          (pet) => NovaConsultaPage(
            pet: pet,
            service: 'Consulta Geral',
            plan: 'Particular',
          ),
        ),
      ),
      (
        titulo: 'Configurações',
        icone: Icons.settings_outlined,
        pagina: (_) => const ConfigScreen(),
      ),
      (
        titulo: 'Gabriela - Splash',
        icone: Icons.medical_services_outlined,
        pagina: (_) => const GabrielaSplashScreen(),
      ),
      (
        titulo: 'Gabriela - Login',
        icone: Icons.lock_outline,
        pagina: (_) => const LoginPage.veterinarianDemo(),
      ),
      (
        titulo: 'Gabriela - Perfil',
        icone: Icons.person_outline,
        pagina: (_) => const GabrielaAreaPage(initialIndex: 0),
      ),
      (
        titulo: 'Gabriela - Chat',
        icone: Icons.chat_bubble_outline,
        pagina: (_) => const GabrielaAreaPage(initialIndex: 1),
      ),
      (
        titulo: 'Gabriela - Agenda',
        icone: Icons.calendar_month_outlined,
        pagina: (_) => const GabrielaAreaPage(initialIndex: 2),
      ),
      (
        titulo: 'Gabriela - Configurações',
        icone: Icons.settings_outlined,
        pagina: (_) => const GabrielaAreaPage(initialIndex: 3),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Telas do projeto')),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: telas.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final tela = telas[index];
          return SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                if (selectionMode) {
                  Navigator.pop<WidgetBuilder>(context, tela.pagina);
                  return;
                }

                final routeName = switch (tela.titulo) {
                  'Splash' => '/',
                  'Login' => '/login',
                  'Pets' => '/pets',
                  'Agenda' => '/agenda',
                  'Gabriela - Splash' => '/gabriela/splash',
                  'Gabriela - Login' => '/gabriela/login',
                  'Gabriela - Perfil' => '/gabriela/perfil',
                  'Gabriela - Chat' => '/gabriela/mensagens',
                  'Gabriela - Agenda' => '/gabriela/agenda',
                  'Gabriela - Configurações' => '/gabriela/configuracoes',
                  _ => null,
                };
                if (routeName != null) {
                  Navigator.pushNamed(context, routeName);
                  return;
                }
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: tela.pagina),
                );
              },
              icon: Icon(tela.icone),
              label: Text(tela.titulo),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          );
        },
      ),
    );
  }
}
